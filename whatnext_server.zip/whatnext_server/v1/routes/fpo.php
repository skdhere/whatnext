<?php 

    /**
    * 
    */
    class Db_fpo
    {
        private $conn;
        private $tablename = "";
        private $gen_insert_query;
        private $gen_data_array;
        private $gen_update_query;
        private $gen_update_data_array;

        function __construct($table_name,$data=array())
        {
            require_once dirname(__FILE__) . '/../../include/DbConnect.php';
            // opening db connection
            $db         = new DbConnect();
            $this->conn = $db->PDO();
            $this->tablename = $table_name;

            $res = $this->conn->query("SHOW COLUMNS FROM ".$this->tablename)->fetchAll();

            $this->getInsertQuery($res,$data);
            $this->getUpdateQuery($res,$data);
            
        }

        

        private function getInsertQuery($array,$data)
        {
            $db_col_array =array();

            foreach($array as $arr)
            {
                array_push($db_col_array,$arr['Field']);
            }

            $insertData = array();

            foreach($data as $col => $val)
            {
                if(in_array($col,$db_col_array))
                {
                    $insertData[$col] = $val;
                }
            }

            $sql = "INSERT INTO ". $this->tablename."";
            $fields = array();
            $values = array();
            foreach( $insertData as $field => $value )
            {
                $fields[] = $field;
                $values[] = "'".$value."'";
            }
            $fields = ' (' . implode(', ', $fields) . ')';
            $values = '('. implode(', ', $values) .')';
            
            $sql .= $fields .' VALUES '. $values;

            $this->gen_insert_query = $sql;
        }

        private function getUpdateQuery($array,$data)
        {
            $db_col_array =array();

            foreach($array as $arr)
            {
                array_push($db_col_array,$arr['Field']);
            }

            $insertData = array();

            foreach($data as $col => $val)
            {
                if(in_array($col,$db_col_array))
                {
                    $insertData[$col] = $val;
                }
            }

            $sql = "UPDATE ". $this->tablename .' SET ';
            $fields = array();
            $values = array();
            
            foreach($insertData as $field => $value )
            {   
                $sql  .= $field ."='".$value."' ,";
            }
            $sql   =chop($sql,',');
            
            $sql .=" WHERE id =".@$insertData['id']." ";

            $this->gen_update_query = $sql;
        }

        function getAll($data)
        {
            $resp_array  =  array();

            $offet       = $data['offset'];
            $limit       = $data['limit'];
            
        //  $STH =$this->conn->prepare("SELECT * FROM tbl_fpo WHERE fpo_status=0 ORDER BY fpo_modified DESC,fpo_created DESC LIMIT ".$offet.",".$limit." ");
            $sql    = " SELECT tf.*,tca.emailId as fpo_email,tca.contactno as fpo_mobile,tca.password as fpo_password FROM tbl_fpo  as tf ";
            $sql   .= " INNER JOIN tbl_change_agents as tca ON tf.id=tca.organisation ";
            $sql   .= " WHERE fpo_status=0 AND userType ='fpo' ORDER BY fpo_modified DESC,fpo_created DESC LIMIT ".$offet.",".$limit." ";
            $STH =$this->conn->prepare($sql);
            $result = $STH->execute();
                
            while($row = $STH->fetch(PDO::FETCH_ASSOC))
            {
                array_push($resp_array,$row);
            }
            return $resp_array;
        }


        function addFpo()
        {
            $query = $this->gen_insert_query;
            $stmt = $this->conn->prepare($query);

            $result = $stmt->execute();
            // Check for successful insertion
            if ($result) {
                // Farmer successfully inserted
                $last_id = $this->conn->lastInsertId();
                return $last_id;

            } else {
                // Failed to create Farmer
                return false;
            }
        }

        function updateFpo()
        {
            $query = $this->gen_update_query;
            $stmt = $this->conn->prepare($query);

            $result = $stmt->execute();
            // Check for successful insertion
            if ($result) {
                // Farmer successfully inserted
                return true;
            } else {
                // Failed to create Farmer
                return false;
            }
        }

        function getAllFpo($fpo_ids)
        {
            $resp_array   = array();

            if(!empty($fpo_ids))
            {
                 $placeHolders = implode(', ', array_fill(0, count($fpo_ids), '?'));
                 $STH =$this->conn->prepare("SELECT * FROM tbl_fpo WHERE fpo_status=0  AND id NOT IN ($placeHolders)  ORDER BY id DESC");
                foreach ($fpo_ids as $index => $value) 
                {
                    $STH->bindValue($index + 1, $value, PDO::PARAM_INT);
                }
            }else
            {
                $STH =$this->conn->prepare("SELECT * FROM tbl_fpo WHERE fpo_status=0  ORDER BY id DESC  ");
            }

            $result = $STH->execute();
              
            while($row = $STH->fetch(PDO::FETCH_ASSOC))
            {
                array_push($resp_array,$row);
            }
            return $resp_array;

        }

        function deleteFpo($id)
        {
             $STH =$this->conn->prepare("UPDATE tbl_fpo SET fpo_status = 1 WHERE id=".$id." ");
             $result = $STH->execute();
             if($result)
             {
                return true;
             }else
             {
                return false;
             }

        }
        
        
        function isEmailExist($email_id,$isUpdate)
        {
            $STH    = $this->conn->prepare("SELECT * FROM tbl_change_agents WHERE emailId = '".$email_id."'");
            $result = $STH->execute();
            
            if($isUpdate=='true')
            {
                $cnt = 2;
            }else
            {
                $cnt = 1;
            }

            if ($STH->rowCount()<$cnt) 
            {
                return false;
            }
            else{
               return true;
            }
        }

        function isMobileExist($mobile,$isUpdate)
        {
            $STH    = $this->conn->prepare("SELECT * FROM tbl_change_agents WHERE contactno = '".$mobile."'");
            $result = $STH->execute();


            if($isUpdate==='true')
            {
                $cnt = 2;
            }else
            {
                $cnt = 1;
            }

            
            if ($STH->rowCount() < $cnt) 
            {
                 return false; 
            }
            else{
                 return true;
            }
        }

        function addEntryToAgent($data)
        {
            $sql  = " INSERT INTO tbl_change_agents (userType,password,fname,organisation,emailId,contactno,register_dt) VALUES ";
            $sql .= "('fpo','".$data['fpo_password']."','".$data['fpo_name']."','".$data['organisation']."','".$data['fpo_email']."','".$data['fpo_mobile']."','".date('Y-m-d h:i:s')."')";

            $stmt = $this->conn->prepare($sql);

            $result = $stmt->execute();
            // Check for successful insertion
            if ($result) {
                return true;
            } else {
                // Failed to create Farmer
                return false;
            }
        }
        
        function getReport($filterData)
        {
            $resp_array  = array();
            $sql = "select `f`.`fm_caid` AS `fm_caid`,`c`.`fname` AS `name`,count(`f`.`fm_caid`) AS `total`, (select count(id) from tbl_farmers where fm_caid =c.id AND f_status =0 ";
            if(isset($filterData['startDate']) && $filterData['startDate']!="" && isset($filterData['endDate']) && $filterData['endDate']!="")
            {
                $startDate = $filterData['startDate'];//explode('-',$filterData['startDate']);
                $startDate = $startDate.' 00:00:00';

                $endDate = $filterData['endDate'];
                $endDate = $endDate.' 23:59:59';

                $sql .=" AND (fm_createddt >= '".$startDate."' AND fm_createddt <= '".$endDate."') ";
            }

            $sql .= ") as total_farmer from (`acrefin_agribridge_2017`.`tbl_farmers` `f` join `acrefin_agribridge_2017`.`tbl_change_agents` `c` on((`f`.`fm_caid` = `c`.`id`))) where (`f`.`f_status` = 0) AND c.isTester = 0 AND f.insert_type = 0 ";

            if(isset($filterData['startDate']) && $filterData['startDate']!="" && isset($filterData['endDate']) && $filterData['endDate']!="")
            {
                $sql .=" AND (fm_createddt >= '".$startDate."' AND fm_createddt <= '".$endDate."') ";
            }

            $sql .= "  group by `f`.`fm_caid` ORDER BY total ASC ";

            
            $STH =$this->conn->prepare($sql);
            $result = $STH->execute();
                
            while($row = $STH->fetch(PDO::FETCH_ASSOC))
            {
                $data['fm_caid']       = $row['fm_caid'];
                $data['name']          = $row['name'];
                $data['total']         = $row['total_farmer'];
                $data['complete']      = $row['total'];
                $data['incomplete']    = $data['total']-$data['complete'];
                array_push($resp_array,$data);
            }
            return $resp_array;
        }
    }

    $app->post('/get_fpo', 'authenticate', function() use ($app){
        verifyRequiredParams(['offset', 'limit']); //provide a list of required parametes
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        

        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            $return_data = $db->getAll($data);
            
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                
            } else {
                $response["success"] = false;
                $response["data"] = [
                    ["error_code" => "103", "error_message" => "Data could not be update."]
                ];
                echoResponse(201, $response);
            }
            echoResponse(201, $response);
        }
    });

    $app->post('/fpo', 'authenticate', function() use ($app){
        // verifyRequiredParams(['fpo_name','fpo_state','fpo_district','fpo_taluka','fpo_village']); //provide a list of required parametes
        verifyRequiredParams(['fpo_name','fpo_mobile','fpo_email','fpo_password']); //provide a list of required parametes

        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        
        $data['ca_id']   = $user_id;

        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            
            $last_id     = $db->addFpo($data);
            
            $data['organisation'] = $last_id;
            $return_data = $db->addEntryToAgent($data);
            
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                
            } else {
                $response["success"] = false;
                $response["data"] = [
                    ["error_code" => "103", "error_message" => "Data could not be update."]
                ];
                echoResponse(201, $response);
            }
            echoResponse(201, $response);
        }
    });

    $app->put('/fpo', 'authenticate', function() use ($app){
        verifyRequiredParams(['fpo_name','fpo_state','fpo_district','fpo_taluka','fpo_village','id']); //provide a list of required parametes
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        
        $data['ca_id']   = $user_id;

        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            $return_data = $db->updateFpo($data);
            
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                
            } else {
                $response["success"] = false;
                $response["data"] = [
                    ["error_code" => "103", "error_message" => "Data could not be update."]
                ];
                echoResponse(201, $response);
            }
            echoResponse(201, $response);
        }
    });

    $app->post('/get_all_fpo', 'authenticate', function() use ($app){
        //provide a list of required parametes
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        
        $fpo_ids    = array();

        if(isset($data['fpo_ids']) && $data['fpo_ids'] !="")
        {
            $fpo_ids = explode(',',$data['fpo_ids']);
        }

        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            $return_data = $db->getAllFpo($fpo_ids);
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                
            } else {
                $response["success"] = false;
                $response["data"] = [
                    ["error_code" => "103", "error_message" => "Data could not be update."]
                ];
                echoResponse(201, $response);
            }
            echoResponse(201, $response);
        }
    });

    $app->post('/delete_fpo', 'authenticate', function() use ($app){
        verifyRequiredParams(['id']);
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        
        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            $return_data = $db->deleteFpo($data['id']);
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                
            } else {
                $response["success"] = false;
                $response["data"] = [
                    ["error_code" => "103", "error_message" => "Data could not be deleted."]
                ];
                echoResponse(201, $response);
            }
            echoResponse(201, $response);
        }
    });
    
     $app->post('/checkFpoEmail', 'authenticate', function() use ($app){
        verifyRequiredParams(['emailId','isUpdate']);
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        
        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            $return_data = $db->isEmailExist($data['emailId'],$data['isUpdate']);
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                echoResponse(201, $response);
                
            } else {
                $response["success"] = false;
                $response["data"] = $return_data;
                echoResponse(201, $response);
            }
            
        }
    });

    $app->post('/checkFpoMobile', 'authenticate', function() use ($app){
        verifyRequiredParams(['contactno','isUpdate']);
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;
        
        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {

            $db          = new Db_fpo('tbl_fpo',$data);
            $return_data = $db->isMobileExist($data['contactno'],$data['isUpdate']);
            
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] = $return_data;
                 echoResponse(201, $response);
                
            } else {
                $response["success"] = false;
                $response["data"] = $return_data;
                echoResponse(201, $response);
            }
           
        }
    });
    
    $app->post('/getReport', 'authenticate', function() use ($app){
        // verifyRequiredParams(['contactno','isUpdate']);
        //fetching the post data into variable
        $data = $app->request->post();
        $err_data = [];
        global $user_id;
        
        $db          = new Db_fpo('tbl_fpo',array());
        $return_data = $db->getReport($data);
        
        if ($return_data !== false) {
            $response["success"] = true;
            $response["data"] = $return_data;
             echoResponse(201, $response);
            
        } else {
            $response["success"] = false;
            $response["data"] = $return_data;
            echoResponse(201, $response);
        }
    });


