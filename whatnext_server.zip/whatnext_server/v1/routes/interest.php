<?php 

        class Db_interest
        {
            private $conn;
            private $tablename        = "";
            private $fm_ids_arr       = array();
            private $tbl_arr          = array();
            
          
            

            function __construct()
            {
                require_once dirname(__FILE__) . '/../../include/DbConnect.php';
                // opening db connection
                $db             = new DbConnect();
                $this->conn     = $db->PDO();
            }

            public function getInterest()
            {
                $resp_array   = array();

                $STH =$this->conn->prepare("SELECT * FROM tbl_interests WHERE status=1  ORDER BY id DESC  ");
                
                $result = $STH->execute();
                  
                while($row = $STH->fetch(PDO::FETCH_ASSOC))
                {
                    $data['name'] = $row['name'];
                    $data['display_name'] = $row['display_name'];
                    array_push($resp_array,$data);
                }
                return $resp_array;
            }
        }

        $app->post('/getInterest', function() use ($app){
         //provide a list of required parametes
        
        //declare variables
        $data = $app->request->post(); //fetching the post data into variable
        $err_data = [];
        global $user_id;

        if($err_data !== []){
            $response["success"] = false;
            $response["data"] = $err_data;
            echoResponse(201, $response);
        }else
        {
            $db          = new Db_interest();
            
            $return_data = $db->getInterest();
             
            if ($return_data !== false) {
                $response["success"] = true;
                $response["data"] =[$return_data];
                echoResponse(201, $response);
            } else {
                $response["success"] = false;
                $response["data"] =$return_data;
                echoResponse(201, $response);exit();
            }
            
        }
    });

?>