<?php 


/** Database config */
//define('DB_USERNAME', 'root');  
//define('DB_PASSWORD', '');
if($_SERVER['HTTP_HOST'] == 'localhost' || $_SERVER['HTTP_HOST'] == '192.168.0.19'){
	define('DB_USERNAME', 'root');  
	define('DB_PASSWORD', '');  
	define('DB_HOST', 'localhost');  
	define('DB_NAME', 'what_next_db');
}else{
	define('DB_USERNAME', '');  
	define('DB_PASSWORD', '');  
	define('DB_HOST', 'localhost');  
	define('DB_NAME', 'what_next_db');
}


/** Debug modes */
define('PHP_DEBUG_MODE', true);  
define('SLIM_DEBUG', true);


